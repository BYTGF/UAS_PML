// import 'dart:convert';
// import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:uts/add_item.dart';
import 'package:uts/mydrawal.dart';

import 'colors.dart';
import 'db_manager.dart';

class ItemList extends StatefulWidget {
  const ItemList({Key? key}) : super(key: key);

  @override
  _ItemListState createState() => _ItemListState();
}

class _ItemListState extends State<ItemList> {
  final dbHelper = DatabaseHelper.instance;
  List<Map<String, dynamic>> allCategoryData = [];

  @override
  void initState() {
    super.initState();
    _query();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () {
                 // Show the dialog when the button is pressed
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return Dialog(
                      child: AddItem(),
                    );
                  },
                );
              },
              child: Text('Button on Top'),
            ),
            Expanded(
              child: ListView.separated(
                itemCount: 4, // Number of ListTile items (each repeated twice)
                separatorBuilder: (BuildContext context, int index) {
                  return Divider(); // Divider widget between ListTile items
                },
                itemBuilder: (BuildContext context, int index) {
                  return ListTile(
                    leading: Icon(Icons.account_circle),
                    title: Text('Title $index'),
                    subtitle: Text('Subtitle $index'),
                    trailing: 
                    Column(
                      children: [
                        Icon(Icons.arrow_forward),
                        Icon(Icons.arrow_forward),
                      ],
                    ), 
                    onTap: () {
                      // Add your onTap logic here
                    },
                  );
                },
              ),
            ),
          ],
        ),
      )
      
    );
  }

  void _query() async {
    final allRows = await dbHelper.queryAllRowsofItem();
    print('query all rows:');
    allRows.forEach(print);
    allCategoryData = allRows;
    setState(() {});
  }

  void _delete(int id) async {
    // Assuming that the number of rows is the id for the last row.
    final rowsDeleted = await dbHelper.deleteItem(id);
    print('deleted $rowsDeleted row(s): row $id');
    _query();
  }
}
